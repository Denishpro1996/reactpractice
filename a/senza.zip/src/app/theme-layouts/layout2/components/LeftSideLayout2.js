import { memo } from 'react';

function LeftSideLayout2() {
  return <></>;
}

export default memo(LeftSideLayout2);

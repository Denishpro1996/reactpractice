import React from "react";
// import Marketingnav from "../navbars/Navbars/Marketingnav";
import "./inquiry.css";
import Application from '../../components/marketing/Application'
import InquiryTable from "../tables/marketingtable/InquiryTable";
const Inquiry = () => {
  return (
    <>
     <InquiryTable/>
    </>
  );
};

export default Inquiry;

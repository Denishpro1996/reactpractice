import React from 'react'
import EmployeeCard from './EmployeeCard';
import './Employee.css';
const Employee = () => {
  return (
    <div >
      <EmployeeCard/> 
      </div>
    
  )
}

export default Employee;

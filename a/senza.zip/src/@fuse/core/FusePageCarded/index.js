export { default } from './FusePageCarded';
